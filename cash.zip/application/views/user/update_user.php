 <section class="features-section-5 bg-image-3 relative">
            <div class="container">
                <div class="row section-separator">

                    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12">
                        <div class="form-outer background-light">

                            <!-- Start: Section Header -->
                            <div class="section-header col-xs-12">

                                <h2 class="section-heading">Update User Details</h2>

                            </div>
                            
							<form method="post" class="single-form" action="<?php echo base_url().'index.php/Home/do_update_user';?>">

                           		 <div class="col-sm-6">

                                    	<input value="<?php echo $_SESSION['first_name']; ?>" name="first_name" class="contact-subject form-control" type="text" placeholder="First Name"  required>
                                 </div>

                                 <div class="col-sm-6">
                                    	<input value="<?php echo $_SESSION['last_name']; ?>" name="last_name" class="contact-subject form-control" type="text" placeholder="Last Name"  required>
                                 </div>
                                 <div class="col-sm-6">
                                    	<input value="<?php echo $_SESSION['username']; ?>" name="username" class="contact-subject form-control" type="text" placeholder="Username"  required>
                                 </div>

                                  <div class="col-sm-6">
                                    	<input value="<?php echo $_SESSION['email']; ?>" readonly name="email" class="contact-subject form-control" type="text" placeholder="email@email.com"  required>
                                 </div>

                                 <div class="col-sm-6">
                                    	<input value="<?php echo $_SESSION['password']; ?>" name="password" id="password" class="contact-subject form-control" type="password" placeholder="Password"  required>
                                 </div>
                                
                                 <div class="col-sm-6">
                                    	<input value="<?php echo $_SESSION['phone']; ?>" name="phone" class="contact-subject form-control" type="text" placeholder="Phone Number"  required>
                                 </div>


                                 <div class="btn-form text-center col-xs-12">
                                    <input class="btn btn-fill right-icon" type="submit" value="Update User" /> 
                                </div>
                            	
                            </form>

                            </div></div></div></div></section>


         