<section class="features-section-1 relative background-semi-dark" id="features">
            <div class="container">
                <div class="row section-separator">

                    <!-- Start: Section Header -->
                    <div class="section-header col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">

                        <h2 class="section-heading">User Dashboard</h2>

                    </div>
                    <!-- End: Section Header -->
                    <?php if($notifications){ $c = 1;?>
                    <table  class="table"  style="color:red;">
                    <thead>
                        <th>
                            SN
                        </th>
                        <th>
                            New Notifications!
                        </th>
                    </thead>
                    <?php foreach($notifications as $notification){?>
                    <tr>
                        <td>
                            <?php echo $c++;?>
                        </td>
                        <td>
                            <?php echo $notification['message']; $this->Notification_model->deactivate_notification($notification["id"]); }?>
                        </td>
                    </tr>
                    </table><?php }?>

                    <div class="col-lg-4">
                    <a href="<?php echo base_url().'index.php/Home/make_donation'; ?>" class="btn btn-fill btn-block">Make Donation</a>
                    <a onclick="return confirm('You Would Like To Deactivate This Account And Register In Another Level. Is That Correct?');" href="<?php echo base_url().'index.php/Home/leave_level/'.$_SESSION['id']; ?>" class="btn btn-fill btn-block">Change Level</a>
                    <i class="icons8-id-card"></i></span>
                    <label>My CashLite Account<br><small>(Please make sure your details are accurate)</small></label>

                    <table class=" table table-striped">
                    <tr><th colspan="10">User Details</th></tr>
                    <tr>
                    	<th>Last Name</th>
                    	<td>
                    	<?php echo $_SESSION['first_name']; ?>
                    		
                    	</td>
                    </tr>

                     <tr>
                    	<th>First Name</th>
                    	<td>
                    	<?php echo $_SESSION['last_name']; ?>
                    		
                    	</td>
                    </tr>

                     <tr>
                    	<th>Username</th>
                    	<td>
                    	<?php echo $_SESSION['username']; ?>
                    		
                    	</td>
                    </tr>

                     <tr>
                    	<th>Email Address</th>
                    	<td>
                    	<?php echo $_SESSION['email']; ?>
                    		
                    	</td>
                    </tr>

                     <tr>
                    	<th>Phone Number</th>
                    	<td>
                    	<?php echo $_SESSION['phone']; ?>
                    		
                    	</td>
                    </tr>

                     <tr>
                    	<th>Level</th>
                    	<td>
                    	<?php echo $_SESSION['level']; ?>
                    		
                    	</td>
                    </tr>

                    <tr>
                    <td colspan="10"><a href="<?php echo base_url().'index.php/Home/update_user';?>" class="btn btn-fill btn-block">Update My Details</a></td>
                    </tr>
                    </table>

                    </div>

                    <div class="col-lg-8">
                    
                    <b style="color:red;"><?php echo $message; ?></b>
                    	<ul class="tab">
                    		<li>
                    			<a href="javascript:void(0)" class="tablinks" onclick='openCity(event, "bankaccount")'>Bank Account</a>
                    		</li>
                    		<li>
                    			<a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'match')">Match</a>
                    		</li>
                            <li>
                                <a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'amountdue')">Amount Due</a>
                            </li>
                    	</ul>


                        

                        <div id="match" class="tabcontent">
                            <h3>Matches</h3>
                            <?php 
                            if($matchedaspayer){ 
                                //die(var_dump($matchedaspayer));
                                 $c=1; ?>
                            <table class="table table-striped">
                            <tr><th colspan="10">You Have Been Matched To Pay:</th></tr>
                                <tr>
                                    <th>SN</th>
                                    <th>Date</th>
                                    <th>Amount</th>
                                    <th>Payee</th>
                                    <th style="color:red;">Time Elapsed(48 Hour Limit)</th>
                                    <th>Action</th>
                                </tr>
                                <?php
                                 foreach($matchedaspayer as $match){
                                    $payee = $this->User_model->get_user_by_id($match['user_id']);
                                    ?>
                                <tr>
                                    <td><?php echo $c++; ?></td>
                                    <td><?php echo $match['date'];?></td>
                                    <td><?php echo $match['amount'];?></td>
                                    <td><?php echo $payee['username'];}?></td>
                                    <td style="color:red;"><?php echo $this->Match_model->HumanTiming(strtotime($match['date']));?></td>
                                    <td>
                                    <?php if($match['proof']){
                                        ?>
                                        <h7>Proof Has Been Uploaded, Awaiting Confirmation</h7>
                                        <?php
                                        }if($match['proof']<1){?>
                                    <form method="post" action="<?php echo base_url().'index.php/Home/upload_proof';?>">
                                        <input type="hidden" name="match_id" value="<?php echo $match['id'];?>">
                                        <input type="submit" value="upload proof" class="btn btn-fill">
                                    </form><?php }?></td>
                                </tr>
                            </table>
                            <?php }else{echo "<p><b>No Matches as Payer.</b></p>";}?>
<hr>

                            <?php 
                            if($matchedaspayee){ 
                                //die(var_dump($matchedaspayer));
                                 $c=1; ?>
                            <table class="table table-striped">
                            <tr><th colspan="10">You Have Been Matched To Get Paid</th></tr>
                                <tr>
                                    <th>SN</th>
                                    <th>Date</th>
                                    <th>Amount</th>
                                    <th>Payer</th>
                                    <th style="color:red;"><small>Time Elapsed(48 Hour Limit)</small></th>
                                    <th>Action</th>
                                </tr>
                                <?php
                                 foreach($matchedaspayee as $match){
                                    $payee = $this->User_model->get_user_by_id($match['payer']);
                                    ?>
                                <tr>
                                    <td><?php echo $c++; ?></td>
                                    <td><?php echo $match['date'];?></td>
                                    <td><?php echo $match['amount'];?></td>
                                    <td><?php echo $payee['username'];}?></td>
                                    <td style="color:red;"><?php echo $this->Match_model->HumanTiming(strtotime($match['date']));?></td>
                                    <td>
                                        <?php if($match['proof']){?>
                                        <a href="<?php echo base_url().'index.php/Home/confirm/'.$match['id'];?>" class="btn btn-fill">Confirm Payment</a>
                                        <?php}else{echo "Awaiting Payment";}?>
                                    </td>
                                </tr><?php }?>
                            </table>
                            <?php }else{echo "<p><b>No Matches as Recipient.</b></p>";}?>
                        </div>

                    	<div id="bankaccount" class="tabcontent">
  							<h3>Bank Account</h3>
 						 <p><?php if($bank_account){?>
 						 		<table class="table table-striped">
 						 			<tr>

 						 				<th>
 						 					Account Name
 						 				</th>
 						 				<td><?php echo $bank_account['account_name']; ?></td>
 						 			</tr>
 						 			<tr>
 						 				<th>
 						 					Account Number
 						 				</th>
 						 				<td>
 						 					<?php echo $bank_account['account_number']; ?>
 						 				</td>
 						 			</tr>
 						 			<tr>
 						 				<th>
 						 					Bank Name
 						 				</th>
 						 				<td>
 						 					<?php echo $bank_account['bank_name']; ?>
 						 				</td>
 						 			</tr>
 						 			<tr>
 						 				<td colspan="10">
 						 					<a href="<?php echo base_url().'index.php/Home/update_account'; ?>" class="btn btn-fill btn-block" >Update Account Details</a>
 						 				</td>
 						 			</tr>
 						 		</table>
 						 <?php }else{?>
 						 		<h5 style="color: red;">You have not added your bank account details. Note that you cannot be matched to receive payment until you have done so.</h5>
 						 		<a href="<?php echo base_url().'index.php/Home/add_account'; ?>" class="btn btn-fill btn-block">Add Bank Account</a>
 						 	<?php }?>
 						 </p>
						</div>
                    	


                        <div id="amountdue" class="tabcontent">
                            <h3>Amount Due</h3>
                            <?php
                            if($amount_due){ $counter = 1; ?>
                            <table class="table table-striped">
                            <thead>
                                <th>
                                    SN
                                </th>
                                <th>
                                   Amount
                                </th>
                                <th>
                                    Amount Matched
                                </th>
                            </thead><tbody>
                            
                                       
                                       <tr>
                                           <td>
                                              <?php echo $counter++; ?> 
                                           </td>
                                           <td>
                                               <?php echo $amount_due['amount_due'];?>
                                           </td>
                                           <td>
                                               <?php echo $amount_due['amount_matched'];?>
                                           </td>
                                       </tr>

                                    
                                    </tbody></table>

                                                     <?php           }
                             ?>
                        </div>
                    </div>



</div></div></section>

<script type="text/javascript">
 
                    var m = document.createEvent('Event');
        openCity(m, "bankaccount")

                         function openCity(evt, cityName) {
    // Declare all variables
    var i, tabcontent, tablinks;

    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

 
   document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

</script>