 <section class="features-section-5 bg-image-3 relative">
            <div class="container">
                <div class="row section-separator">

                    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12">
                        <div class="form-outer background-light">

                            <!-- Start: Section Header -->
                            <div class="section-header col-xs-12">

                                <h2 class="section-heading">Upload Proof</h2>

                            </div>
                            
							<form enctype="multipart/form-data" method="post" class="single-form" action="<?php echo base_url().'index.php/Home/do_upload';?>">

                           		 <div class="col-sm-6">
                                 <label>Select Picture</label>
                                 <input type="file" name="userfile">
                                    	
                                                                         </div>

                                   <input type="hidden" name="match_id" value="<?php echo $match_id; ?>">

                                  <div class="btn-form text-center col-xs-12">
                                    <input class="btn btn-fill right-icon" type="submit" value="Upload" /> 
                                </div>

                                 </form>
                                 </div>
                                 </div></div></div></section>