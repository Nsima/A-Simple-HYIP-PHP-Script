 <section class="features-section-5 bg-image-3 relative">
            <div class="container">
                <div class="row section-separator">

                    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12">
                        <div class="form-outer background-light">

                            <!-- Start: Section Header -->
                            <div class="section-header col-xs-12">

                                <h2 class="section-heading">Update Account Details</h2>
                            </div>
                            
							<form method="post" class="single-form" action="<?php echo base_url().'index.php/Home/do_update_account';?>">
                                <input name="parent_url" hidden type="text" value="admin"  required>

                           		 <div>

                                    	<input name="account_name" class="contact-subject form-control" type="text" value="<?php echo $bank_account['account_name'];?>" placeholder="Enter Account Name"  required>
                                 </div>

                                  <div>

                                        <input name="account_number" class="contact-subject form-control" type="text" placeholder="Enter Account Number"  required value="<?php echo $bank_account['account_number'];?>">
                                 </div>

                                  <div>

                                        <input name="bank_name" class="contact-subject form-control" type="text" placeholder="Enter Bank Name"  required value="<?php echo $bank_account['bank_name'];?>">
                                 </div>

                                  

                                  <div class="btn-form text-center col-xs-12">
                                    <input class="btn btn-fill right-icon" type="submit" value="Add account" /> 
                                </div>

                                 </form>
                                 </div>
                                 </div></div></div></section>