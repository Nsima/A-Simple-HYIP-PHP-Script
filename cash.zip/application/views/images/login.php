 <section class="features-section-5 bg-image-3 relative">
            <div class="container">
                <div class="row section-separator">

                    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12">
                        <div class="form-outer background-light">

                            <!-- Start: Section Header -->
                            <div class="section-header col-xs-12">

                                <h2 class="section-heading">Your Login</h2>

                            </div>
                            <span id="checkmsg" style="color:red;"><?php echo $message; ?></span>
                            
							<form method="post" class="single-form" action="<?php echo base_url().'index.php/Lindsey_Login/do_login';?>">
                                <input name="parent_url" hidden type="text" value="admin"  required>

                           		 <div class="col-sm-6">

                                    	<input name="email" class="contact-subject form-control" type="text" placeholder="Email"  required>
                                 </div>

                                  <div class="col-sm-6">

                                        <input name="password" class="contact-subject form-control" type="password" placeholder="Enter Password"  required>
                                 </div>

                                  <div class="btn-form text-center col-xs-12">
                                    <input class="btn btn-fill right-icon" type="submit" value="Log In" /> 
                                </div>

                                 </form>
                                 </div>
                                 </div></div></div></section>