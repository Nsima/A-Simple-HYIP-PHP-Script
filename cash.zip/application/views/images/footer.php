

        <!-- Start: Footer Section 1
        ================================== -->
        <footer class="footer-section background-dark" style="background-color: #B02C37;">
            <div class="container">
                <div class="row section-separator text-center">

                    <div class="copyright" style="color:white;">
                        <p>Copyright: &copy;NairaBlast 2017. All rights reserved. /p> <!-- You can keep the link to show us some support :) -->
                    </div>

                </div><!-- End: .section-separator  -->
            </div> <!-- End: .container  -->
        </footer>
        <!-- End: Footer Section 1
        ================================== -->




        
        <!-- SCRIPTS 
        ========================================-->
        <script src="<?php echo base_url(); ?>assets/js/plagin-js/jquery-1.11.3.js"></script>
        <script src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/plagin-js/plagin.js"></script>

        <!-- Custom Script 
        ==========================================-->
        <script src="<?php echo base_url(); ?>assets/js/custom-scripts.js"></script>

    </body>

</html>