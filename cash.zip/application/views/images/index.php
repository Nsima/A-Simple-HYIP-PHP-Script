<section class="features-section-1 relative background-semi-dark" id="features">
            <div class="container">
                <div class="row section-separator">

                    <!-- Start: Section Header -->
                    <div class="section-header col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">

                        <h2 class="section-heading">Admin Dashboard</h2> <b><i class="glyphicon glyphicon-refresh"></i></b>
                    </div>
<div class="col-lg-12">
 <b style="color:red;"><?php echo $message; ?></b>
                        <ul class="tab">
                            <li>
                                <a href="javascript:void(0)" class="tablinks" onclick='openCity(event, "all_users")'>All Users</a>
                            </li>
                               <li>
                                <a href="javascript:void(0)" class="tablinks" onclick='openCity(event, "all_admin_users")'>Admin Users</a>
                            </li>
                            <li>
                                <a href="javascript:void(0)" class="" s="tablinks" onclick="openCity(event, 'add_user')">Add User</a>
                            </li>
                            <li>
                                <a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'payers')">Eligible Payers</a>
                            </li>
                            <li>
                                <a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'payees')">Eligible Payees</a>
                            </li>
                             <li>
                                <a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'matches')">Matches</a>
                            </li>
                            
                        </ul>
<div id="all_admin_users" class="tabcontent">
    <h3>All Admin Users</h3>
    <table class="table table-striped">
    <thead>
        <th>SN</th>
        <th>Username</th>
        <th>Email</th>
        <th>Make Payee</th>
    </thead>
    <tbody>
    <?php $c = 1;  foreach($admin_users as $admin_user){?>
                        <tr>
                        <td>
                        <?php echo $c++; ?>
                        </td>
                        <td>
                        <?php echo $admin_user['username']; ?>
                        </td>
                        <td>
                        <?php echo $admin_user['email']; ?>
                        </td>
                        <td>
                            <a href="<?php $id = $admin_user['id']; $level = $admin_user['level'];echo base_url();?>index.php/Lindsey/make_payee/<?php echo $id; ?>/<?php echo $level;?>/" class="btn btn-fill" >Make Payee</a>
                        </td>
                        </tr> <?php } ?>                    </b>
                            </tbody></table>
</div>
 
 
 <div id="all_users" class="tabcontent">
    <h3>All Users</h3>
    <table class="table table-striped">
    <thead>
        <th>SN</th>
        <th>Username</th>
        <th>Email</th>
        <th>Make Payee</th>
    </thead>
    <tbody>
    <?php $c = 1;  foreach($users as $user){?>
                        <tr>
                        <td>
                        <?php echo $c++; ?>
                        </td>
                        <td>
                        <?php echo $user['username']; ?>
                        </td>
                        <td>
                        <?php echo $user['email']; ?>
                        </td>
                        <td>
                            <a href="<?php $id = $user['id']; $level = $user['level'];echo base_url();?>index.php/Lindsey/make_payee/<?php echo $id; ?>/<?php echo $level;?>/" class="btn btn-fill" >Add To Payee </a>
                        </td>
                        </tr> <?php } ?>                    </b>
                            </tbody></table>
</div>

<div class="tabcontent" id="add_user">
                    	<a href="<?php echo base_url().'index.php/Lindsey/add_payee/1';?>" class="btn btn-fill">Add Level 1 Payee</a><br><br>

                        <a href="<?php echo base_url().'index.php/Lindsey/add_payee/2';?>" class="btn btn-fill">Add Level 2 Payee</a><Br><br>

                        <a href="<?php echo base_url().'index.php/Lindsey/add_payee/3';?>" class="btn btn-fill">Add Level 3 Payee</a><br><br>

                        <a href="<?php echo base_url().'index.php/Lindsey/add_payee/4';?>" class="btn btn-fill">Add Level 4 Payee</a><Br><Br>

                        <a href="<?php echo base_url().'index.php/Lindsey/add_payee/5';?>" class="btn btn-fill">Add Level 5 Payee</a><Br><Br>
                    	
                            </div>
 
 <div class="tabcontent" id="payers">
     <h3>All Eligible Payers</h3>
     <?php if($payers){?>
     <table class="table table-striped">
         <thead>
         <th>SN</th>
         <th>Email</th>
         <th>Amount Pledged</th>
         <th>Date Pledged</th>
         </thead>
       <?php foreach($payers as $payer){?>
         <tr>
             <td><?php echo $c++; ?></td>
             <td><?php echo $this->User_model->get_user_by_id($payer['user_id'])['email'];  ?></td>
             <td><?php echo $payer['amount'];?></td>
             <td><?php echo $payer['date'];?></td>
         </tr>
       <?php } ?>
     </table>
    <?php }else{echo "<B>No Eligible Payers</b>";}?>
 </div>
 
 <div class="tabcontent" id="payees">
     <h3>All Eligible Payees</h3>
     <?php if($payees){?>
     <table class="table table-striped">
         <thead>
         <th>SN</th>
         <th>Email</th>
         <th>Amount Pledged</th>
         <th>Date Pledged</th>
         </thead>
       <?php foreach($payees as $payee){?>
         <tr>
             <td><?php echo $c++; ?></td>
             <td><?php echo $this->User_model->get_user_by_id($payee['user_id'])['email'];  ?></td>
             <td><?php echo $payee['amount_due'];?></td>
             <td><?php echo $payee['date_added'];?></td>
         </tr>
       <?php } ?>
     </table>
    <?php }else{echo "<B>No Eligible Payees</b>";}?>
 </div>
 
 <div class="tabcontent" id="matches">
     <h3>All Current Matches</h3>
     <?php if($matches){?>
     <table class="table table-striped">
         <thead>
         <th>SN</th>
         <th>Payee</th>
         <th>Payer</th>
         <th>Amount</th>
         <td>Date</td>
         <td>Time Elapsed</td>
         </thead>
       <?php foreach($matches as $match){?>
         <tr>
             <td><?php echo $c++; ?></td>
             <td><?php echo $this->User_model->get_user_by_id($match['user_id'])['email'];  ?></td>
             <td><?php echo $this->User_model->get_user_by_id($match['payer'])['email'];?></td>
             <td><?php echo $match['amount']; ?></td>
             <td><?php echo $match['date'];?></td>
             <td><b style="color:red;"><?php echo $this->Match_model->humanTiming(strtotime($match['date']));?></b></td>
         </tr>
       <?php } ?>
     </table>
    <?php }else{echo "<B>No Current Matches</b>";}?>
 </div>
</div>
                    </div>
                    </div>
                    </section>


<script type="text/javascript">
 
                    var m = document.createEvent('Event');
        openCity(m, "all_users")

                         function openCity(evt, cityName) {
    // Declare all variables
    var i, tabcontent, tablinks;

    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

 
   document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

</script>