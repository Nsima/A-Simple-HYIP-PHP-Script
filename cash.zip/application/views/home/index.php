
        
        <!-- Start: Header Section
        ================================ -->
        <section class="header-section-1 bg-image-1 header-js" id="header" >
            <div class="overlay-color">
                <div class="container">
                    <div class="row section-separator">

                        <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1">
                            <div class="part-inner text-center">

                                <!--  Header SubTitle Goes here -->
                                <h1 class="title">CashLite</h1> 

                                <div class="detail" >
                                    <h3 style="color:white;">Say GoodBye To Financial Stress</h3>
                                </div>

                                <!-- Button Area -->
                                <div class="btn-form btn-scroll">
                                    <a href="#features" class="btn btn-fill right-icon">View Packages <i class="icon icons8-advance"></i></a>
                                </div>

                            </div>
                        </div> <!-- End: .part-1 -->

                    </div> <!-- End: .row -->
                </div> <!-- End: .container -->
            </div> <!-- End: .overlay-color -->
        </section>
        <!-- End: Header Section
        ================================ -->



 



        <!-- Start: Features Section 1
        ====================================== -->
        <section class="features-section-1 relative background-semi-dark" id="features">
            <div class="container">
                <div class="row section-separator">

                    <!-- Start: Section Header -->
                    <div class="section-header col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">

                        <h2 class="section-heading">Get Started</h2>
                        <p class="sub-heading"><B>Choose any of the following levels to register, and begin your way towards financial freedom. <small style="color:red;">Note The Level You Choose.</small></B></p>

                    </div>
                    <!-- End: Section Header -->

                    <div class="clearfix"></div>

                    <div class="col-xs-12 features-item">
                        <div class="row">
                            
                            <div class="each-features text-center col-md-4 col-sm-6 col-xs-12">
                                <div class="inner background-light">
                            
                                    <i class="icon features-icon icons8-clock"></i>
                                    <h6 class="title">Starter(N5,000)</h6>
                                    <div class="detail">
                                        <p>
                                        <form action="<?php echo base_url().'index.php/Login';?>" method="post"><input type="hidden" name="level" value="1"/>
                                        <input type="submit" class="btn btn-fill right-icon" value="Log In"></form></p>
                                        <p><a href="<?php echo base_url(); ?>index.php/Login/register/1" class="btn btn-fill right-icon">Register Now</a></p>
                                    </div>

                                </div> <!-- End: .inner -->
                            </div> <!-- End: .each-features -->

 
                            <div class="each-features text-center col-md-4 col-sm-6 col-xs-12">
                                <div class="inner background-light">
                            
                                    <i class="icon features-icon icons8-clock"></i>
                                    <h6 class="title">Standard(N10,000)</h6>
                                    <div class="detail">
                                        <p> <form action="<?php echo base_url().'index.php/Login';?>" method="post"><input type="hidden" name="level" value="2"/>
                                        <input type="submit" class="btn btn-fill right-icon" value="Log In"></form></p>
                                        <p><a href="<?php echo base_url(); ?>index.php/Login/register/2" class="btn btn-fill right-icon">Register Now</a></p>
                                    </div>

                                </div> <!-- End: .inner -->
                            </div>

                            
                            <div class="each-features text-center col-md-4 col-sm-6 col-xs-12">
                                <div class="inner background-light">
                            
                                    <i class="icon features-icon icons8-clock"></i>
                                    <h6 class="title">Premium(N20,000)</h6>
                                    <div class="detail">
                                        <p> <form action="<?php echo base_url().'index.php/Login';?>" method="post"><input type="hidden" name="level" value="3"/>
                                        <input type="submit" class="btn btn-fill right-icon" value="Log In"></form></p>
                                        <p><a href="<?php echo base_url(); ?>index.php/Login/register/3" class="btn btn-fill right-icon">Register Now</a></p>
                                    </div>

                                </div> <!-- End: .inner -->
                            </div> <!-- End: .each-features -->

                            

                        </div>
                    </div>

                </div> <!-- End: .row -->
            </div> <!-- End: .container -->
        </section>
        <!-- End: Features Section 1
        ======================================-->
            <div class="container">
                <div class="row section-separator">

                    <!-- Start: Section Header -->
                    <div class="section-header col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">

                        <h2 class="section-heading" style="color: white;">HOW IT WORKS</h2><hr>
                        <h4 style="text-align: left; color: white;">
 The system is the first of its type that pays it member without any REFERRAL. It a Mutual Aid Programmed. When a member registers free of charge, the member will have 2 hours to donate a minimum of ten thousand Naira to a member to be matched. This is one time donation. Once you complete your donation, you will be matched with two other new members to donate same amount you donated to you.<br>
                Our packages are Starter ₦10,000, Bronze ₦20,000, Silver ₦50,000, Gold ₦100,000, Platinum ₦250,000. Register and join any package of your choice, donate to the individual account as assigned by the system before 2 hours ultimatum. On receiving payment from a payer, you are required to confirm the payer. Once confirmed, the system automatically assigns two (2) persons to pay you. After receiving complete payment the system automatically exits you and you can re-join any package of your choice.<Br>
                All disagreements and problems will be manually handled ASAP by system administrator. Submit a support ticket to report any issues<br>
                <strong>*MULTIPLE ACCOUNTS ARE NOT ALLOWED.</strong><br> 
                <strong>WELCOME TO FINANCIAL FREEDOM!!!!</strong><br>
                <strong>NOTE:</strong> Cyber Beggars are not permitted on this platform, Kindly Write to support ASAP on any user who requests for activation before payment. Report any issue to <em>naira6blast@gmail.com</em>
</h4>

                    </div>
                    <!-- End: Section Header -->


                   
                               
                               

                             
                    </div> <!-- End: .col-md-8 -->

                </div> <!-- End: .row -->
            </div> <!-- End: .container -->
        </section>
        <!-- End: Features Section 3
        ================================== -->