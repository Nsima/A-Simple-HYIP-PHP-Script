<section class="features-section-5 bg-image-3 relative">
            <div class="container">
                <div class="row section-separator">

                    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12">
                        <div class="form-outer background-light">

                            <!-- Start: Section Header -->
                            <div class="section-header col-xs-12">

                                <h2 class="section-heading"></h2> </div>
<b>Terms and conditions</b></h2><hr>
By signing up on NairaBlast you agree to the following terms and conditions guiding our operation.
<ul>

<li>You are of a right and stable mind</li>
<li>You were not forced or deceived to be part of NairaBlast</li> 
<li>You are of legal age to invest</li>
<li>We reserve the right to terminate cunny investors membership and delete their account</li>
<li>We reserve the right to add or remove any feature of NairaBlast without notice.</li>
<li>All payment are willingly sent to fellow investors and a refund is not possible.</li>
<li>In an unlikely scenario of loss of funds, NairaBlast operators, its owners, employees, investor
shall not be held liable for any loss whatsoever</li>
<li>Any participant who fails to make payment to his/her beneficiary after 48 hours, will be deleted from our system.</li></ul>
</div></div></div></div></div></section>

