 <section class="features-section-5 bg-image-3 relative">
            <div class="container">
                <div class="row section-separator">

                    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12">
                        <div class="form-outer background-light">

                            <!-- Start: Section Header -->
                            <div class="section-header col-xs-12">
                            	Frequently Asked Questions(FAQ)
                            </div>


<br><br><b>What is CashLite?</b><br>
CashLite is a platform specially designed to utilize the population of Nigeria for wealth creation for Nigerians. Its a peer to peer recycling platform, where members pay members according to the package
we have and get x2 of what they paid from other members.
<br><br><b>Where is CashLite located?</b><br>
CashLite is a company located in Australia, with a business model to reduce the dependency ration
on African countries, by creating wealth for themselves through their large population. Nigeria is the
first country where our business model is being lunched, we will in time subsequently move to other
countries.
<br><br><b>Do I need to bring referrals?</b><br>
No. CashLite is not a site that works on referrals. So you don’t need to bring referrals. But we have
referral bonus for members who wished to publicized CashLite as a means of encouragement to
those committed members, they will receive 5% of what their referral pays.
<br><br><b>How do I earn in CashLite?</b><br>
You earn by activation one of our packages upon sigining up, after you pay to fellow member, two
members will be assigned to pay you x2 of that amount. But its important each member recycle by
activating other packages after receiving payment.
<br><br><b>How do I receive my payment?</b><br>
After you have paid and been confirmed, you will receive payment from two members through local
bank transfer.
<br><br><b>Can I activate more than one package at the same time?</b><br>
Yes you can. An investor can choose to activate all 4 packages at the same times, and he will receive
payment from all packages, nothing is mutually exclusive.
<br><br><b>Is multiple account allowed?</b><br>
Theres no rule against opening multiple accounts, but each has to be with a different email, phone
number and username. Although we don’t think that will be necessary since a single account can
activate more than one package.
<br><br><b>Is CashLite sustainable?</b><br>
Yes its 100% sustainable, a lot of thought, planning and testing were put in place to make it 100%
sustainable.
<br><br><b>Will CashLite be Available in other African countries?</b><br>
Yes, CashLite will be available shortly in some selected African countries in some few months.
Nigeria is the first country to experience our business model, with her sheer population and our stableplatform lots of wealth wil be created for Nigerians. We are giving the power to make wealth back to the
people.<br>
<br>Welcome Nigeria to a world where earning has no limit <i>-CashLite</i>
                            </div></div></div></div></section>