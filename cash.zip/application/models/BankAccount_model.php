<?php 
class BankAccount_model extends CI_Model{

			public function __construct(){
				parent::__construct(); 

			}

			public function get_user_account($user_id){
				$result = $this->db->get_where("bank_account", array("user_id"=>$user_id))->result_array();
				if(count($result)){
					return $result[0];
				}else{
					return null; 
				}
			}

			public function add_account($id, $bank_name, $account_number, $account_name){

				$check = $this->db->get_where("bank_account", array('user_id'=>$id))->result_array();
				if(count($check)){
					return null; 
				}else{
				$data = array(
					'user_id'=>$id,
					'bank_name'=>$bank_name, 
					'account_number'=>$account_number, 
					'account_name'=>$account_name
					); 
				$this->db->set($data);
				$this->db->insert("bank_account"); 
				return 1; 
			}


			}


			public function update_account($id, $bank_name, $account_number, $account_name){

				$data = array(
					'bank_name'=>$bank_name, 
					'account_number'=>$account_number, 
					'account_name'=>$account_name
					); 
				$this->db->set($data);
				$this->db->where("user_id", $id); 
				$this->db->update("bank_account"); 
				return 1;
			}

		}