<?php 
class User_model extends CI_Model{

			public function __construct(){
				parent::__construct(); 

			}

			public function anihilate_user($id){
				$this->db->trans_begin();
				$this->db->query("DELETE FROM user where id=$id");
				$this->db->query("DELETE FROM payer where user_id=$id");
				$this->db->query("DELETE FROM payee where user_id=$id");
				$this->db->query("DELETE FROM notifications where user_id=$id");
				$this->db->query("DELETE FROM matched where user_id=$id");
				$this->db->query("DELETE FROM matched where payer=$id");
				$this->db->query("DELETE FROM bank_account where user_id=$id");

				$this->db->trans_complete();
				return 1; 
			}
                        
                        

			public function logIn($email, $password, $level){

				$result = $this->db->get_where("user", array('email'=>$email, 'password'=>$password, 'level'=>$level))->result_array();
				//die(var_dump($result));
				if(count($result)>0){
					$user = $result[0]; 
					
					$data  = array(

						'id'=>$user['id'],
						'first_name'=>$user['first_name'], 
						'last_name'=>$user['last_name'], 
						'username'=>$user['username'], 
						'email'=>$user['email'], 
						'phone'=>$user['phone'], 
						'password'=>$user['password'], 
						'parent_url'=>$user['parent_url'], 
						'level'=>$user['level'],
                                                'user'=>1
					);

					$this->session->set_userdata($data);
					return true;
				}else{
					return false;
				}
			}


			public function getUserByEmailAndPassword($email, $password){

				$result = $this->db->get_where("user", array('email'=>$email, 'password'=>$password))->result_array();

				die(var_dump($result));

			}

			public function checkIfEmailRegistered($email, $level){
				$result = $this->db->get_where("user", array('email'=>$email, "level"=>$level))->result_array();

				if(count($result)>0){
					return true;
				}else{
					return false;
				}
			}


			public function registerUser($first_name, $last_name, $username, $email, $password, $phone, $parent_url, $level){

				$data  = array(
						'first_name'=>$first_name, 
						'last_name'=>$last_name, 
						'username'=>$username, 
						'email'=>$email, 
						'phone'=>$phone, 
						'password'=>$password, 
						'parent_url'=>$parent_url, 
						'level'=>$level
					); 

				$this->db->set($data);
				$this->db->insert("user"); 
				$this->logIn($email, $password, $level);
				return 1; 

			}

			public function registerAdminUser($first_name, $last_name, $username, $email, $password, $phone, $parent_url, $level){

				$data  = array(
						'first_name'=>$first_name, 
						'last_name'=>$last_name, 
						'username'=>$username, 
						'email'=>$email, 
						'phone'=>$phone, 
						'password'=>$password, 
						'parent_url'=>$parent_url, 
						'level'=>$level
					); 

				$this->db->set($data);
				$this->db->insert("user"); 
				return 1; 

			}

			public function update_user($first_name, $last_name, $phone, $password, $username, $email){
				$data = array(
					'first_name'=>$first_name, 
					'last_name'=>$last_name, 
					'phone'=>$phone, 
					'password'=>$password, 
					'username'=>$username
					);
				$this->db->set($data);
				$this->db->where("id", $_SESSION['id']);
				$this->db->update("user"); 
				$this->logIn($email, $password);
				
				return 1; 
			}

			public function get_user_by_id($user_id){
				$r = $this->db->get_where("user", array("id"=>$user_id))->result_array();
				if(count($r)){
					return $r[0]; 
				}else{
					return null; 
				}
			}

			
		}