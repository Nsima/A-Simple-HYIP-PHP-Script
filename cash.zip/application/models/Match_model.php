<?php 
class Match_model extends CI_Model{

			public function __construct(){
				parent::__construct(); 
				$this->load->model("Mail_model");
				$this->load->model("User_model");
				$this->load->model("BankAccount_model");
				$this->load->model("Notification_model");
				$this->load->model("Payer_model");
				$this->load->model("Payee_model");
				$this->load->model("Proof_model");

			}

			function humanTiming ($time)
		{

    $time = time() - $time; // to get the time since that moment
    $time = ($time<1)? 1 : $time;
    $tokens = array (
        31536000 => 'year',
        2592000 => 'month',
        604800 => 'week',
        86400 => 'day',
        3600 => 'hour',
        60 => 'minute',
        1 => 'second'
    );

    foreach ($tokens as $unit => $text) {
        if ($time < $unit) continue;
        $numberOfUnits = floor($time / $unit);
        return $numberOfUnits.' '.$text.(($numberOfUnits>1)?'s':'');
    }   

}
                public function get_matches(){
                    $result = $this->db->get("matched")->result_array();
                    if(count($result))return result;
                    return null; 
                }

		public function get_match($match_id){
			$result = $this->db->query("SELECT * from matched where id=$match_id")->result_array();
				if(count($result))return $result[0];
				return null;
		}

		public function update_match_confirm($match_id){
			$this->db->query("UPDATE matched set proof=1 where id=$match_id");
			return 1;
		}


			public function get_payer_match($user_id){
				$result = $this->db->query("SELECT * from matched where payer=$user_id")->result_array();
				if(count($result))return $result;
				return null; 
			}

			public function get_payee_match($user_id){
				$result = $this->db->get_where("matched", array("user_id"=>$user_id))->result_array();
				if(count($result))return $result;
				return null; 
			}


			public function check_parent_url_in_user_table($parent_url){
				$r = $this->db->get_where("user", array("email"=>$parent_url))->result_array();
				if(count($r)){
					return $r[0]; 
				}else{
					return null; 
				}
			}	

			public function check_parent_url_in_match_table($user_id){
				$r = $this->db->query("SELECT * FROM matched where user_id=$user_id")->result_array();
				if(count($r)){
					return $r; 
				}else{
					return null; 
				}
			}


			public function check_parent_has_children($user_id){
				$r = $this->db->query("SELECT * FROM children where user_id=$user_id")->result_array();
				if(count($r)){
					return $r; 
				}else{
					return null; 
				}
			}

			public function add_child($user_id){
				$this->db->query("UPDATE children set children=children+1 where user_id=$user_id");
				return 1; 
							}


			public function make_first_child($user_id){
				$data = array("user_id"=>$user_id);
				$this->db->set($data);
				$this->db->insert("children");
				return 1;
			}


			public function get_amount_due($level){
				$amount_due = 0;
				switch ($level) {
					case 1:
						$amount_due = 10000; 
						break;

					case 2:
						$amount_due = 20000; 
						break;


					case 3:
						$amount_due = 40000; 
						break;

					case 4:
						$amount_due = 100000; 
						break;
				}
				return $amount_due; 
			}


			public function make_payee($user_id, $level){
				$amount_due = $this->get_amount_due($level);
				$data = array(
					"user_id"=>$user_id,
					"amount_due"=>$amount_due, 
					"amount_matched"=>0
					);
				$this->db->set($data);
				$this->db->insert("payee");
				return 1;
			}

			public function children_update($parent_url){
				$parent_exists = $this->check_parent_url_in_user_table($parent_url);
				if($parent_exists){
					$parent_has_children = $this->check_parent_has_children($parent_exists['id']);
						if($parent_has_children){
							//check no of children
							//if children < 2, add 1, continue. if children 2, continue
							$no_of_children=$parent_has_children['children'];
							if($no_of_children){
								if($no_of_children<2){
									$this->add_child($parent_exists['id']); 
									$this->Mail_model->first_child_is_born($parent_exists['email']); 
								}
								//check no of children again
							$no_of_children=$parent_has_children['children'];
								//add to payee list
								if($no_of_children==2){
									$this->make_payee($parent_exists['id'], $parent_exists['level']);
									$this->Mail_model->second_child_is_born($parent_exists['email']); 
								}
							}
						}else{
								$this->make_first_child($parent_exists['id']);
							}
					die(var_dump($parent_has_children));
				}
				return 0; 

			}


			public function check_parent_is_payee($user_id){
				$r = $this->db->get_where("payee", array("user_id"=>$parent_url))->result_array();
				if(count($r)){
					return $r[0]; 
				}else{
					return null; 
				}
			}

			public function get_earliest_payee(){
				$earliest = $this->db->query("SELECT * FROM payee ORDER BY date_added ASC LIMIT 10")->result_array();
//

				if(count($earliest)>0){
					foreach ($earliest as $e) {

						if($e['amount_matched'] != $e['amount_due'])return $e;

					}
					return null; 
				}

				return null; 
			}

		   public function get_earliest_payer(){
				$earliest = $this->db->query("SELECT * FROM payer ORDER BY date ASC LIMIT 10")->result_array();


				if (count($earliest)) {
					foreach ($earliest as $e) {
						if($e['amount']!=$e['amount_matched'])return $e;
						return null; 
					}
						//die();

				return null; 
				}
				return null; 
			}

			public function get_amount_to_pay($amount_pledged, $amount_due){
				$result  = 0;
				 if($amount_pledged>$amount_due)
						$result = $amount_pledged-$amount_due;


				 if($amount_pledged<$amount_due)
						$result = $amount_due-$amount_pledged;
					
				 if($amount_pledged==$amount_due)
						$result = $amount_pledged;

				return $result; 
			}

			public function match_payer(){
				$payer = $this->get_earliest_payer();
				$payee = $this->get_earliest_payee();			
                                //die(var_dump($payee));
                                
				if(!$payer || !$payee)return 0;
				//die(var_dump($payee));
				if($payee){
                                    if($payee['user_id']==$payer['user_id'])return 0;
                                $amount_pledged = $payer['amount'] - $payer['amount_matched'];

					$amount_due = $payee['amount_due']-$payee['amount_matched'];

					$this->db->trans_begin();
					$payer = $this->User_model->get_user_by_id($payer['user_id']);
					$payee = $this->User_model->get_user_by_id($payee['user_id']);
					$amount_to_pay= $this->get_amount_to_pay($amount_pledged, $amount_due);
					$account = $this->BankAccount_model->get_user_account($payee['id']);
					
					$this->add_match($payee['id'], $amount_to_pay, $payer['id']);
					$this->update_payer($payer['id'], $amount_to_pay);
					$this->update_payee($payee['id'], $amount_to_pay);

					$this->db->trans_complete();

					//send notifications
					$this->Mail_model->mail_payer($payer, $payee, $account, $amount_to_pay);
					$this->Mail_model->mail_payee($payer, $payee, $amount_to_pay);
					$this->Notification_model->create_notification($payer['id'], "You have been matched to pay a beneficiary. Check 'Match Section' for details.");
					$this->Notification_model->create_notification($payee['id'], "You have been matched to get paid. Check 'Match Section' and your email for details.");



				}
			}

			public function update_payer($user_id, $amount){
				$this->db->query("UPDATE payer set amount_matched = amount_matched+$amount where user_id=$user_id");
				return 1; 
			}

			public function update_payee($user_id, $amount){
				$this->db->query("UPDATE payee set amount_matched = amount_matched+$amount where user_id=$user_id");
				return 1; 
			}


			public function add_match($user_id, $amount, $payer){
				$data = array(
					"user_id"=>$user_id,
					"amount"=>$amount,
					"payer"=>$payer
					); 
				$this->db->set($data);
				$this->db->insert("matched");
				$this->Mail_model->mail_payer($this->User_model->get_user_by_id($payer), $this->User_model->get_user_by_id($user_id), $this->BankAccount_model->get_user_account($user_id), $amount); 
				$this->Notification_model->create_notification($payer,"You have been matched. Check 'Match' Section for details.");

				$this->Notification_model->create_notification($user_id, "You have been matched. Check 'Match' Section for details.");
				$this->Mail_model->mail_payee($this->User_model->get_user_by_id($payer), $this->User_model->get_user_by_id($user_id), $amount);
					//mail and notif to payer, payee 


			}

			//get 
			//check if parent is a payee
			/*
				true: check if amount_due == amount_matched
				*/
			public function match_update(){
				$parent = $this->check_parent_url_in_user_table($parent_url);
				$user_id = $parent['id'];
				$parent_is_payee = $this->check_parent_is_payee($user_id);
				if($parent_is_payee){
					$fully_matched = $parent_is_payee['amount_due']==$parent_is_payee['amount_matched'];
					if(!$fully_matched){
						//get earliest registered user with account details
						$fully_matched=$fully_matched['amount_matched']; 
						if($amount_matched==0){

						}
					}
				}
			}

			public function delete_match($id){
				$this->db->query("DELETE FROM matched where id=$id");
				return 1;
			}


			public function confirm_payment($matched_id){
				/*
		delete proof 
		delete matched
		update payer 
		update payee
		send notifications to payee, payer
		*/
			$this->db->trans_begin();
			$match = $this->get_match($matched_id);
			$payer = $this->User_model->get_user_by_id($match['payer']);
			$this->Proof_model->delete_proof($matched_id);
			$this->delete_match($matched_id);
			$this->Payer_model->payer_confirm($match['payer'], $match['amount']);
			$this->Payee_model->payee_confirm($match['user_id'], $match['amount']);
			$this->Payee_model->make_payee($match['payer'], $payer['level']);
			$this->db->trans_complete();
			//send nofications
			$this->Notification_model->create_notification($match['payer'], "Your Beneficiary Has Confirmed Payment Receipt. You wil be matched within the next 5 days.");

			}

		}