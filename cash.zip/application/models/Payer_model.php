<?php 
class Payer_model extends CI_Model{

			public function __construct(){
				parent::__construct(); 
				$this->load->model("Mail_model");
				$this->load->model("Match_model");
			}
                        
                        public function get_all_payers(){
                            $result = $this->db->get("payer")->result_array();
                            if(count($result)>0)return $result;
                            return null;
                        }


			public function check_if_payer($user_id){
				$r = $this->db->get_where("payer", array("user_id"=>$user_id))->result_array();
				if(count($r)){
					return $r[0]; 
				}else{
					return null; 
				}
			}

			public function add_payer($user_id, $amount){
				$data = array(
					"user_id"=>$user_id, 
					"amount"=>$amount, 
					"amount_matched"=>0
					);
				$this->db->set($data);
				$this->db->insert("payer");
				$this->Match_model->match_payer("user_id");
				return 1; 

			}

			public function get_amount($user_id){
				$r = $this->db->get_where("payer", array("user_id"=>$user_id))->result_array();
				if(count($r))return $r[0]; 
				return null; 
			}

		public function get_amount_tobepaid($level){
				$amount_tobepaid = 0;
				switch ($level) {
					case 1:
						$amount_tobepaid = 5000; 
						break;

					case 2:
						$amount_tobepaid = 10000; 
						break;


					case 3:
						$amount_tobepaid = 20000; 
						break;

					case 4:
						$amount_tobepaid = 50000; 
						break;
				}
				return $amount_tobepaid; 
			}

			public function delete_payer($user_id){
				$this->db->query("DELETE FROM payer where user_id=$user_id");
				return 1; 
			}

			public function payer_confirm($id, $amount){
//subtract amount from amount to pay, if amount =0, delete,else update
				$payer = $this->check_if_payer($id);
				$balance = $payer['amount'] - $amount; 
				$matched_balance = $payer['amount_matched'] - $amount; 
				if($balance >0){
					$data  = array(
						"amount" => $balance, 
						"amount_matched" => $matched_balance
						);
					$this->db->set($data);
					$this->db->where("user_id", $id);
					$this->db->update("payer");
				}
					else{
						$this->delete_payer($payer['user_id']);
					}
					return 1; 

			}

		}	