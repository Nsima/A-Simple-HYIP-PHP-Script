<?php 
class Lindsey_model extends CI_Model{

			public function __construct(){
				parent::__construct(); 
			}


			public function log_in($email, $password){

				$result = $this->db->get_where("admin", array('email'=>$email, 'password'=>$password))->result_array();

				if(count($result)>0){
					$user = $result[0]; 
					
					$data  = array(

						'id'=>$user['id'],
						'email'=>$user['email'], 
						'password'=>$user['password'], 
						'admin'=>1
					);

					$this->session->set_userdata($data);
					return true;
				}else{
					return false;
				}
			}

			public function get_all_admin_users(){
				$r = $this->db->get_where("user", array("parent_url"=>"admin"))->result_array();
				if(count($r)){
					return $r; 					
				}else{
					return null; 
				}
			}
                        
                        public function get_all_users(){
                            return $this->db->get("user")->result_array();
                        }


		}