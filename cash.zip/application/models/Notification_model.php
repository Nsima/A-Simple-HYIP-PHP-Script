<?php 
class Notification_model extends CI_Model{

			public function __construct(){
				parent::__construct(); 

			}


			public function create_notification($user_id, $message){

				$data = array(
					'user_id'=>$user_id, 
					'message'=>$message, 
					'activated'=>1
									);
				$this->db->set($data);
				$this->db->insert("notifications");
			}

			public function check_notifications($user_id){
				$result = $this->db->get_where("notifications", array("user_id"=>$user_id, "activated"=>1))->result_array();
				if(count($result)){
					return $result;
				}
				return null;
			}

			public function deactivate_notification($id){
				$data = array("activated"=>0);
				$this->db->set($data);
				$this->db->where("id", $id);
				$this->db->delete("notifications");
				return 1; 
			}

			}