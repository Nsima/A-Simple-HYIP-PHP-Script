<?php 
class Mail_model extends CI_Model{

			public function __construct(){
				parent::__construct(); 

			}


			public function mail_user($to, $subject, $message){
				mail($to, $subject, $message, 'From: ');
			}

			public function first_child_is_born($to){
				mail($to, "NairaBlast: A USER REGISTERED UNDER YOU!", "Hi there. You now have one child. Get another in order to get matched to recieve payment. Cheers from NairaBlast.", 'From: ');
			}


			public function second_child_is_born($to){
				mail($to, "NairaBlast: A USER REGISTERED UNDER YOU!", "Hi there and congratulations! You now have two children. You will be matched to recieve your amount due within the next seven days. Cheers from NairaBlast.", 'From: ');
			}


			public function mail_payer($payer, $payee, $account, $amount){
				mail($payer['email'], "NairaBlast: YOU HAVE BEEN MATCHED", "Hi there. You have been matched to pay ".$payer['username']." the sum of $amount within 48 hours. Here are the details: Account Name: ".$account['account_name']." |Account Number: ".$account['account_number']." |Bank Name: ".$account['bank_name'].". Failure to pay within 48 hours will result in your getting erased from the system. Have a wonderful day");
			}

			public function mail_payee($payer, $payee, $amount){
				mail($payee["email"], "NairaBlast: YOU HAVE BEEN MATCHED", "Hi there. You have been matched to receive $amount from ".$payer['username']." , Phone:".$payer['phone']." within 48 hours. Cheers.");
			}

			public function proof_mail_payee($payer, $payee, $amount){
					mail($payee['email'], "NairaBlast: YOU HAVE BEEN PAID", "Hi there. Your match, ".$payer['username']." has uploaded proof of payment for the sum of N".$amount.". Please confirm this in your 'Match' Section. Cheers");
			}
		}