<?php 
class Proof_model extends CI_Model{

			public function __construct(){
		parent:: __construct();
	}

	function add_proof($matched_id, $pic_name){
		$data = array(
				'matched_id'=>$matched_id, 
				'pic_name'=>$pic_name
			);

		$this->db->set($data);
		$this->db->insert("proof");
	}

	function delete_proof($id){
		$this->db->query("DELETE FROM proof where id=$id");
		return 1; 
	}

	 
}





?>