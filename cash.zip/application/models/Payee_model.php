<?php 
class Payee_model extends CI_Model{

			public function __construct(){
				parent::__construct(); 
				$this->load->model("Mail_model");
			}
                        
                        public function get_all_payees(){
                            $result = $this->db->get("payee")->result_array();
                            if(count($result)>0)return $result;
                            return null;
                        }


			public function check_user_is_payee($user_id){
				$r = $this->db->get_where("payee", array("user_id"=>$user_id))->result_array();
				if(count($r)){
					return $r[0]; 
				}else{
					return null; 
				}
			}




			public function make_payee($user_id, $level){
				$amount_due = $this->get_amount_due($level);
				$data = array(
					"user_id"=>$user_id,
					"amount_due"=>$amount_due, 
					"amount_matched"=>0
					);
				$this->db->set($data);
				$this->db->insert("payee");
				return 1;
			}

		  public function get_amount_due($level){
				$amount_due = 0;
				switch ($level) {
					case 1:
						$amount_due = 10000; 
						break;

					case 2:
						$amount_due = 20000; 
						break;


					case 3:
						$amount_due = 40000; 
						break;

					case 4:
						$amount_due = 100000; 
						break;
				}
				return $amount_due; 
			}

			public function delete_payee($user_id){
				$this->db->query("DELETE FROM payee where user_id=$user_id");
				return 1; 
			}

			public function payee_confirm($id, $amount){
//subtract amount from amount to pay, if amount =0, delete,else update
				$payee = $this->check_user_is_payee($id);
				$balance = $payee['amount_due'] - $amount; 
				$matched_balance = $payee['amount_matched'] - $amount; 
				if($balance >0){
					$data  = array(
						"amount_due" => $balance, 
						"amount_matched" => $matched_balance
						);
					$this->db->set($data);
					$this->db->where("user_id", $id);
					$this->db->update("payee");
				}
					else{
						$this->delete_payee($payee['user_id']);
					}
					return 1; 

			}

}