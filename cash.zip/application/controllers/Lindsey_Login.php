<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lindsey_Login extends CI_Controller {

	public function __construct(){
		parent:: __construct();
		 if(isset($_SESSION['admin'])){
			redirect("/Lindsey");
		}
  		
  		$this->load->model('Lindsey_model');


	}


	public function index($message=""){
		$data['message'] = base64_decode($message);
		$this->load->view("includes/header");
		$this->load->view("images/login", $data);
		$this->load->view("includes/footer");

	}


	public function do_login(){
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		$user_valid = $this->Lindsey_model->log_in($email, $password);
		if($user_valid){
			redirect("/Lindsey");
		}
		else{
			redirect("/Lindsey_Login/index/".base64_encode("Wrong email or password."));
	}
	}

 



}