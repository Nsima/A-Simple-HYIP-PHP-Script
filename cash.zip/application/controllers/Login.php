<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct()
	{
		parent:: __construct();
		if(isset($_SESSION["admin"]))redirect("/Lindsey");
		if(isset($_SESSION["email"]))redirect("/Home");
  		$this->load->model('User_model');
  		$this->load->model('Mail_model');
  		$this->load->model('Notification_model');
	}

	public function index($message=""){
		$data['message'] = base64_decode($message);
		$data['level']=$this->input->post("level");
		$this->load->view("includes/header");
		$this->load->view("home/login", $data);
		$this->load->view("includes/footer");

	}


	public function login($message="", $level=0){
		$data['message'] = base64_decode($message);
		$data['level']=$this->input->post("level");
		$this->load->view('includes/header');
		$this->load->view('home/login', $data);
		$this->load->view('includes/footer');
	}

	public function do_login(){
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$level = intval($this->input->post("level"));
		$user_valid = $this->User_model->logIn($email, $password, $level);
		//die(var_dump($user_valid));
		if($user_valid){
			redirect("/Home");
		}
		else{
			redirect("/Login/login/".base64_encode("Wrong email or password.").'/'.$level);
		}
	}


	public function register($id, $message=""){
		$data['message']=base64_decode($message);
		$data['id'] = $id;  
		$this->load->view("includes/header");
		$this->load->view("home/register", $data);
		$this->load->view("includes/footer");

	}

	public function do_register(){
		$first_name = $this->input->post('first_name');
		$last_name = $this->input->post('last_name');
		$username = $this->input->post('username');
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$level =$id= $this->input->post('level');
		$parent_url = trim($this->input->post('parent_url'));
		if(strlen($parent_url)<5)$parent_url="admin";
		$phone = $this->input->post('phone');
		//check if email registered in database
		$email_registered = $this->User_model->checkIfEmailRegistered($email, $level); 
		if($email_registered){
			redirect("/Login/register/".$id."/".base64_encode("This Email Is Already Registered In This Level."));
		}else{
			$this->User_model->registerUser($first_name, $last_name, $username, $email, $password, $phone, $parent_url, $level);
			//send message to user
			$to = $email; 
			$subject="NAIRABLAST IMPORTANT NOTICE";
			$message = "Hello there and welcome to NairaBlast. Please ensure your personal contact details are accurate, and check your mail and dashboard regularly for updates";
			$this->Mail_model->mail_user($to, $subject, $message);
			$message = "Welcome. Please make sure your contact details are accurate, and add your bank account details as soon as possible to avoid matching details.";
			$this->Notification_model->create_notification($_SESSION['id'], $message);
			redirect("/Home");
		}

	}



	


}


?>