<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lindsey extends CI_Controller {

	public function __construct(){
		parent:: __construct();
                $this->load->model('Match_model');
  		$this->load->model('Payee_model');
  		$this->load->model('Lindsey_model');
  		$this->load->model('User_model');
  		$this->load->model('Mail_model');
  		$this->load->model('Notification_model');
                $this->load->model('Payer_model');
	}   


	public function index($message=""){
		if(!isset($_SESSION['admin'])){
			redirect("/Lindsey_Login");
		}
		$data['message']=base64_decode($message);
                $data['matches'] = $this->Match_model->get_matches();
                $data['users'] = $this->Lindsey_model->get_all_users();
                $data['payers'] = $this->Payer_model->get_all_payers();
                $data['payees'] = $this->Payee_model->get_all_payees();
		$data['admin_users'] = $this->Lindsey_model->get_all_admin_users();
		$this->load->view("images/header");
		$this->load->view("images/index", $data);
		$this->load->view("images/footer");

	}

	public function add_payee($id, $message=""){
		$data['message']=base64_decode($message);
		$data['id'] = $id;  
		$this->load->view("images/header");
		$this->load->view("images/add_user", $data);
		$this->load->view("images/footer");
	}

	public function do_add_payee(){
		$first_name = $this->input->post('first_name');
		$last_name = $this->input->post('last_name');
		$username = $this->input->post('username');
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$level= $id = intval($this->input->post('level'));
		$parent_url = $this->input->post('parent_url');
		$phone = $this->input->post('phone');
		//check if email registered in database
		$email_registered = $this->User_model->checkIfEmailRegistered($email); 
		if($email_registered){
			redirect("/Lindsey/add_payee/".$id."/".base64_encode("This Email Is Already Registered In This Level."));
		}else{
			$this->User_model->registerAdminUser($first_name, $last_name, $username, $email, $password, $phone, $parent_url, $level);
			//send message to user
			$to = $email; 
			$subject="NAIRABLAST IMPORTANT NOTICE";
			$message = "Hello there and welcome to NairaBlast. Please ensure your personal contact details are accurate, and check your mail and dashboard regularly for updates";
			$this->Mail_model->mail_user($to, $subject, $message);
			$message = "Welcome. Please make sure your contact details are accurate, and add your bank account details as soon as possible to avoid matching errors.";
			$this->Notification_model->create_notification($_SESSION['id'], $message);
			redirect("/Lindsey");
		}

	}

	public function make_payee($user_id, $level){//die(var_dump($level));
                $has_account = $this->BankAccount_model->get_user_account($user_id); //die(var_dump($has_account));
                if($has_account){
		$user_is_payee = $this->Payee_model->check_user_is_payee($user_id); 
		if($user_is_payee){
			redirect("/Lindsey/index/".base64_encode("This User Is Already A Payee"));
			return 1; 
		}else{
			$this->Payee_model->make_payee($user_id, $level);
			redirect("/Lindsey/index/".base64_encode("User Successfully Added to Payee List"));

                }}else{
                    redirect("/Lindsey/index/". base64_encode("User Cannot Be Matched Until Bank Account Details Are Added."));
                }
	}

	public function log_out(){
		session_destroy();
		$this->session->unset_userdata($_SESSION);
		redirect("/Lindsey_Login");
	}
}