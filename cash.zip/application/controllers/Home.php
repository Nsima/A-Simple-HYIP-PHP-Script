<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct(){
		parent:: __construct();
                if(isset($_SESSION['admin']))redirect("/Lindsey");
		if(!isset($_SESSION['user']))redirect("/Login");
  		$this->load->model('User_model');
  		$this->load->model('Proof_model');
  		$this->load->model('BankAccount_model');
  		$this->load->model('Notification_model');
  		$this->load->model('Match_model');
  		$this->load->model('Payer_model');
  		$this->load->model('Payee_model');
                $this->match();
	}


	public function index($message=""){
		$data['message'] = base64_decode($message); 
		$data['bank_account'] = $this->BankAccount_model->get_user_account($_SESSION['id']);
		$data['notifications'] = $this->Notification_model->check_notifications($_SESSION['id']);
		$data['amount_due'] = $this->Payee_model->check_user_is_payee($_SESSION['id']);
		$data['matchedaspayer'] = $this->Match_model->get_payer_match($_SESSION['id']);
		$data['matchedaspayee'] = $this->Match_model->get_payee_match($_SESSION['id']);
		$this->load->view("images/header");
		$this->load->view("user/index", $data);
		$this->load->view("includes/footer");
	}

	public function upload_proof(){
		$match_id=$this->input->post("match_id");
		if(!$this->Match_model->get_match($match_id)){redirect("/Home");}
		$data['match_id'] = $match_id;
		$data['match']  = $this->Match_model->get_match($match_id);
		$this->load->view("images/header");
		$this->load->view("user/upload_proof", $data);
		$this->load->view("includes/footer");
	}

	  public function do_upload(){


                    $errors="";
                    $match_id=$this->input->post("match_id");
                   // die(var_dump($match_id));
                    $file_name = $_FILES['userfile']['name'];
      $file_size =$_FILES['userfile']['size'];
      $file_tmp =$_FILES['userfile']['tmp_name'];
      $file_type=$_FILES['userfile']['type'];
        
  $type = explode("/", $file_type)[1];

      if(strlen($errors)<1){
        $destination_path = getcwd().DIRECTORY_SEPARATOR;
        $target_path= $destination_path.'uploads/'.basename($file_name); 
       // die(var_dump($target_path));

        $v= move_uploaded_file($file_tmp, $target_path);
        //die(var_dump($v));
        	//update match set proof to 1, send mail to payee, create Payee Notification
        $this->db->trans_start();
        $this->Proof_model->add_proof($match_id, $file_tmp);
        $match = $this->Match_model->get_match($match_id);
        $this->Match_model->update_match_confirm($match_id);
        $this->Mail_model->proof_mail_payee($this->User_model->get_user_by_id($match['payer']), $this->User_model->get_user_by_id($match['user_id']), $match['amount']);
        $this->Notification_model->create_notification($match['user_id'], "Your Donor Has Uploaded Proof of Payment. Confirm Payment Under 'Match' Section");
        $this->db->trans_complete();
                        redirect('/Home/index/'.base64_encode("Proof of Payment Successfully Uploaded. Make Sure Your Recipient Confirms the Payment As Soon As Possible."));
      }}

    public function confirm($matched_id){

    	$this->Match_model->confirm_payment($matched_id);
    	redirect("/Home/index/".base64_encode("Payment Successfully Confirmed."));

    }

    public function leave_level($id){
    	$checkpayer = $this->Payer_model->check_if_payer($id); 
    	if($checkpayer){
    		redirect("/Home/index/".base64_encode("You Have To Complete Your Pledged Donaton Before You Can Move To Another Level!"));
    		return 0; 
    	}

    	$checkpayee = $this->Payee_model->check_user_is_payee($id);
    	if($checkpayee){
    		redirect("/Home/index/".base64_encode("You Have Some Incoming Funds On This Account. Please Wait Till Your Match Pays You Before You Can Move To Another Level!"));
    		return 0; 
    	}

    	if(!$checkpayer && ! $checkpayee){
    		$done = $this->User_model->anihilate_user($id);

    		if($done){
    			session_destroy();
    			redirect("/HomePage");}
    	}
    	return 0; 

    }

	public function add_account($message=""){
		$data['message'] = base64_decode($message); 
		$this->load->view("images/header");
		$this->load->view("user/add_account", $data);
		$this->load->view("includes/footer");
	}

	public function do_add_account(){

		$bank_name = $this->input->post("bank_name");
		$account_name = $this->input->post("account_name");
		$account_number = $this->input->post("account_number");
		$id = $_SESSION['id'];

		$submit=$this->BankAccount_model->add_account($id, $bank_name, $account_number, $account_name); 

		if($submit){

			redirect("/Home/index/".base64_encode("Account Details successfully added. Click on \"Make Donation\" to get matched")); 
		}else{
			redirect("/Home/add_account/".base64_encode("This user already has a registered email address"));
		}


	}

	public function update_account(){
		$data['bank_account'] = $this->BankAccount_model->get_user_account($_SESSION['id']);
		$this->load->view("images/header");
		$this->load->view("user/edit_account", $data);
		$this->load->view("includes/footer");
	}

	public function do_update_account(){
		$bank_name = $this->input->post("bank_name");
		$account_name = $this->input->post("account_name");
		$account_number = $this->input->post("account_number");
		$id = $_SESSION['id'];

		$submit = $this->BankAccount_model->update_account($id, $bank_name, $account_number, $account_name);
		if($submit)redirect("/Home/index/".base64_encode("Account Successfully updated")); 
	}


	public function update_user(){
		$this->load->view("images/header");
		$this->load->view("user/update_user");
		$this->load->view("includes/footer");
	}

	public function do_update_user(){
		$first_name = $this->input->post("first_name");
		$last_name = $this->input->post("last_name");
		$phone = $this->input->post("phone");
		$password = $this->input->post("password");
		$username = $this->input->post("username");
		$email = $this->input->post("email");
		$this->User_model->update_user($first_name, $last_name, $phone, $password, $username, $email);

		redirect("/Home/index/".base64_encode("Your Profile Has Been Successfully Updated.")); 


	}

	public function make_donation(){

		$user_is_payer = $this->Payer_model->check_if_payer($_SESSION['id']);
                $user_is_payee = $this->Payee_model->check_user_is_payee($_SESSION['id']);
		//die(var_dump($user_is_payer));
		if(!$user_is_payer && !$user_is_payee){
			$this->Payer_model->add_payer($_SESSION['id'], $this->Payer_model->get_amount_tobepaid($_SESSION['level']));

			
$this->match();

			redirect("/Home/index/".base64_encode("Pledge Successfully Made. Expect A Match Within 5 days"));	
                        return 0; 
		}else{
			if($user_is_payer){redirect("/Home/index/".base64_encode("You have already made a pledge. Please check your 'Match' section to see if you have been matched to a recipient."));
                        return 0; 
                        }else{
                            redirect("/Home/index/". base64_encode("You Have Some Incoming Funds. Please Wait Until You Get Paid Before Making Another Pledge."));
                            return 0; 
                        }
					//$this->match();
		}

		//$earliest_payee = $this-> 			
		//get earliest user on payee table
		//match user to pay earliest payee

	}

	public function match(){

		$this->Match_model->match_payer();
		//redirect("/Home");
	}

	public function log_out(){
		session_destroy();
		$this->session->unset_userdata();
		redirect("/HomePage");
	}
	


}


?>