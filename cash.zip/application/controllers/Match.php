<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Match extends CI_Controller {

	public function __construct(){
		parent:: __construct();
		if(count($_SESSION)<2){
			redirect("/Login");
		}
  		$this->load->model('User_model');
  		$this->load->model('BankAccount_model');
  		$this->load->model('Notification_model');
  		$this->load->model('Match_model');

	}

			}
